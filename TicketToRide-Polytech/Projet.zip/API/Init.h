void InitPlayer(t_dataPlayer* dataPlayer, t_dataMap* dataMap);
void InitGame(t_dataMap* dataMap, t_dataPlayer* dataPlayer, t_dataTracks* dataTracks);
void InitTracks(t_dataMap* dataMap, t_dataTracks* dataTracks);
