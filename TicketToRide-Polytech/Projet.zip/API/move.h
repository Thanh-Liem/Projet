void Move(t_move* move);
t_return_code OurMove(t_move* move, int* nb_cards_deck);
int DoReplay(t_move* move, int* nb_play);
void EditMove(t_move* move, t_objective temp_objective[3], t_dataPlayer* dataPlayer, t_dataTracks* dataTracks, t_dataMap* dataMap);
void EditOpponnentMove(t_move* move, t_dataPlayer* dataPlayer, t_dataTracks* dataTracks, t_dataMap* dataMap);
void CheckCompletedObjective(t_dataPlayer* dataPlayer, t_dataTracks dataTracks, t_objective Bestpath[][35]);
