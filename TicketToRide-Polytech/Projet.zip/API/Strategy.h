int calculescore(int length);
void recursiveStrat_increasing(int city1, int city2, t_dataTracks Tracks, int CurrentLength, int *minLength, t_objective listObjective[], t_objective comparelist[], int* bestscore, int currentscore, t_dataPlayer dataPlayer);
void recursiveStrat_decreasing(int city1, int city2, t_dataTracks Tracks, int CurrentLength, int *minLength, t_objective listObjective[], t_objective comparelist[], int* bestscore, int currentscore, t_dataPlayer dataPlayer);
void Strat(int city1, int city2, t_dataTracks Tracks, t_objective BestlistObjective[][35], t_dataPlayer dataPlayer, int number);
void NewObjective(t_move* move, t_dataPlayer dataPlayer, t_dataTracks Tracks, int tabObjective[3]);
void Fake_IA(t_move* move, t_move* OurLastMove, t_dataPlayer dataPlayer, t_dataMap dataMap, t_dataTracks Tracks, t_objective Bestpath[][35]);
