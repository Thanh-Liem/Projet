#include <stdlib.h>
#include <stdio.h>
#include "TicketToRideAPI.h"
#include "clientAPI.h"
#include "Data.h"
#include "Init.h"
#include "move.h"
#include "Strategy.h"

int main(){

	t_dataMap dataMap;
	t_dataPlayer dataPlayer;
	t_dataTracks dataTracks;
	
	t_move move;
	t_move OurLastMove;
	t_return_code return_code;
	
	t_objective temp_objective[3];
	t_objective Bestpath[20][35];
	
	InitTracks(&dataMap, &dataTracks);
	InitGame(&dataMap, &dataPlayer, &dataTracks);
	InitPlayer(&dataPlayer, &dataMap);

	do{
		if(dataPlayer.replay == 0){
			printMap();
		}
		
		if(dataPlayer.num_player == dataPlayer.PlayerWhoPlay){
		
			dataPlayer.nb_play++;
			
			/*Move(&move); */
			
			Fake_IA(&move, &OurLastMove, dataPlayer, dataMap, dataTracks, Bestpath);
			EditMove(&move, temp_objective, &dataPlayer, &dataTracks, &dataMap);
			dataPlayer.replay = DoReplay(&move, &dataPlayer.nb_play);
			return_code = OurMove(&move, &dataPlayer.nb_cards_deck);
		
		}
		/* Opponent move */
		else{
			return_code = getMove(&move, &dataPlayer.replay);		
			EditOpponnentMove(&move, &dataPlayer, &dataTracks, &dataMap);
		}
		
		if( (return_code == NORMAL_MOVE)&&(dataPlayer.replay == 0) ){
			dataPlayer.nb_play = 0;
			dataPlayer.PlayerWhoPlay = !dataPlayer.PlayerWhoPlay;
		}
		
		for(int i=0; i<dataPlayer.Player[dataPlayer.num_player].nb_objectif; i++){
			Strat(dataPlayer.Player[dataPlayer.num_player].arrays_objective[i].city1, dataPlayer.Player[dataPlayer.num_player].arrays_objective[i].city2, dataTracks, Bestpath, dataPlayer, i);
		}

	}while(return_code == NORMAL_MOVE);
		
		
		
	if( (return_code == WINNING_MOVE && dataPlayer.PlayerWhoPlay == dataPlayer.num_player) 
	|| (return_code == LOOSING_MOVE && dataPlayer.PlayerWhoPlay != dataPlayer.num_player)){
	
		printf(" We win !\n");
	}
	else{
		printf(" We lose !\n");
	}
			
	/* Disconnect from server */
	closeConnection();
	printf("Close Success\n");
	
	return EXIT_SUCCESS;
}
