#include <stdlib.h>
#include <stdio.h>
#include "TicketToRideAPI.h"
#include "clientAPI.h"
#include "Data.h"
#include "Init.h"

void InitPlayer(t_dataPlayer* dataPlayer, t_dataMap* dataMap){

	dataPlayer->PlayerWhoPlay = 0;
	dataPlayer->replay = 0;
	dataPlayer->nb_play = 0;
	dataPlayer->nb_cards_deck = 110-5-4-4;
	
	dataPlayer->Player[0].nb_wagon = 45;
	dataPlayer->Player[0].nb_objectif = 0;
	
	dataPlayer->Player[1].nb_wagon = 45;
	dataPlayer->Player[1].nb_objectif = 0;
	
	for(int i=0; i<20; i++){
		dataPlayer->Player[dataPlayer->num_player].completedobjective[i] =0;
	}
	
	for(int i=0; i<10; i++){
		dataPlayer->Player[0].nb_color_cards[i] = 0;
		dataPlayer->Player[1].nb_color_cards[i] = 0;
	}
	for(int i=0; i<4; i++){
		dataPlayer->Player[dataPlayer->num_player].nb_color_cards[dataMap->cards[i]] = dataPlayer->Player[dataPlayer->num_player].nb_color_cards[dataMap->cards[i]] + 1;
	}
}

void InitGame(t_dataMap* dataMap, t_dataPlayer* dataPlayer, t_dataTracks* dataTracks){
	
	/* Connect to server */
	connectToServer("li1417-56.members.linode.com", 5678, "T_bot");
	printf("You are in the server\n");
	
	/* Collect data and wait for a game */
	waitForT2RGame( "TRAINING PLAY_RANDOM map=USA timeout=10000", dataMap->gameName, 
	&dataMap->nbCities, &dataMap->nbTracks);	
	printf("Game name = %s\n", dataMap->gameName);	
	printf("nbCities = %d, nbTracks = %d\n\n", dataMap->nbCities, dataMap->nbTracks);
	
	dataMap->tracks = malloc(5*dataMap->nbTracks*sizeof(int));
	
	dataPlayer->num_player = getMap( dataMap->tracks, dataMap->faceUp, dataMap->cards);
	printf("You are the player %d\n", dataPlayer->num_player);
	
	for(int i=0; i < 5*dataMap->nbTracks ; i=i+5){
	
		dataTracks->lengthTracks[dataMap->tracks[i]][dataMap->tracks[i+1]] = dataMap->tracks[i+2];
		dataTracks->colorTracks[dataMap->tracks[i]][dataMap->tracks[i+1]] = dataMap->tracks[i+3];
		dataTracks->doubleTracks[dataMap->tracks[i]][dataMap->tracks[i+1]] = dataMap->tracks[i+4];
		dataTracks->takenTracks[dataMap->tracks[i]][dataMap->tracks[i+1]] = 0;
		
		dataTracks->lengthTracks[dataMap->tracks[i+1]][dataMap->tracks[i]] = dataMap->tracks[i+2];
		dataTracks->colorTracks[dataMap->tracks[i+1]][dataMap->tracks[i]] = dataMap->tracks[i+3];
		dataTracks->doubleTracks[dataMap->tracks[i+1]][dataMap->tracks[i]] = dataMap->tracks[i+4];
		dataTracks->takenTracks[dataMap->tracks[i+1]][dataMap->tracks[i]] = 0;
	}
}

void InitTracks(t_dataMap* dataMap, t_dataTracks* dataTracks){

	for(int i=0; i< dataMap->nbCities;i++){
		for(int j=0; j< dataMap->nbCities; j++){
		
			dataTracks->lengthTracks[i][j] = 0;
			dataTracks->colorTracks[i][j] = 0;
			dataTracks->doubleTracks[i][j] = 0;
			dataTracks->takenTracks[i][j] = 0;
		}	
	}
}
	
	
	
	
	
	
	
	
	
	
