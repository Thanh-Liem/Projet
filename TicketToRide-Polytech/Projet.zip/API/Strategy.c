#include <stdlib.h>
#include <stdio.h>
#include "TicketToRideAPI.h"
#include "clientAPI.h"
#include "Data.h"

int calculescore(int length){
	
	if(length == 1){
		return 1;}
	if(length == 2){
		return 2;}
	if(length == 3){
		return 4;}
	if(length == 4){
		return 7;}
	if(length == 5){
		return 10;}
	if(length == 6){
		return 15;}
	return 0;
}

void recursiveStrat_increasing(int city1, int city2, t_dataTracks Tracks, int CurrentLength, int *minLength, t_objective listObjective[], t_objective comparelist[], int* bestscore, int currentscore, t_dataPlayer dataPlayer){
						
	if(Tracks.lengthTracks[city1][city2] > 0 && ((Tracks.takenTracks[city1][city2] == 0)|| (Tracks.takenTracks[city1][city2] == 1 ))){
			
		comparelist[CurrentLength].city1 = city1;
		comparelist[CurrentLength].city2 = city2;
		comparelist[CurrentLength].score = calculescore(Tracks.lengthTracks[city1][city2]);
		
		if(CurrentLength+1 < *minLength){		
				for(int j=0; j<CurrentLength+1; j++){
					listObjective[j].city1 = comparelist[j].city1;
					listObjective[j].city2 = comparelist[j].city2;
					listObjective[j].score = comparelist[j].score;
					*bestscore = currentscore + comparelist[CurrentLength].score;
				}
		}
		else{
			if(currentscore + comparelist[CurrentLength].score > *bestscore){
				for(int j=0; j<CurrentLength+1; j++){
						listObjective[j].city1 = comparelist[j].city1;
						listObjective[j].city2 = comparelist[j].city2;
						listObjective[j].score = comparelist[j].score;
						*bestscore = currentscore + comparelist[CurrentLength].score;
				}
			}
		}
		if(Tracks.takenTracks[city1][city2] == 0 ){
			*minLength = CurrentLength+1;
		}
	}	
	else{	
		for(int i=city1; i<city2+3 && i<36; i++){
			if( Tracks.lengthTracks[city1][i] > 0 && ((Tracks.takenTracks[city1][i] == 0)|| (Tracks.takenTracks[city1][i] == 1 ))){
				comparelist[CurrentLength].city1 = city1;
				comparelist[CurrentLength].city2 = i;
				comparelist[CurrentLength].score = calculescore(Tracks.lengthTracks[city1][i]);
				
				if(Tracks.takenTracks[city1][city2] == 0){
					recursiveStrat_increasing(i, city2, Tracks, CurrentLength+1, minLength, listObjective, comparelist, bestscore, currentscore + comparelist[CurrentLength].score, dataPlayer);
				}
				else{
					recursiveStrat_increasing(i, city2, Tracks, CurrentLength, minLength, listObjective, comparelist, bestscore, currentscore + comparelist[CurrentLength].score, dataPlayer);
				}
			}
		}
	}
}

void recursiveStrat_decreasing(int city1, int city2, t_dataTracks Tracks, int CurrentLength, int *minLength, t_objective listObjective[], t_objective comparelist[], int* bestscore, int currentscore, t_dataPlayer dataPlayer){
						
	if(Tracks.lengthTracks[city1][city2] > 0 && ((Tracks.takenTracks[city1][city2] == 0)|| (Tracks.takenTracks[city1][city2] == 1 ))){
			
		comparelist[CurrentLength].city1 = city1;
		comparelist[CurrentLength].city2 = city2;
		comparelist[CurrentLength].score = calculescore(Tracks.lengthTracks[city1][city2]);
		
		if(CurrentLength+1 < *minLength){
				for(int j=0; j<CurrentLength+1; j++){
					listObjective[j].city1 = comparelist[j].city1;
					listObjective[j].city2 = comparelist[j].city2;
					listObjective[j].score = comparelist[j].score;
					*bestscore = currentscore + comparelist[CurrentLength].score;
				}
		}
		else{
			 if(currentscore + comparelist[CurrentLength].score > *bestscore){
				for(int j=0; j<CurrentLength+1; j++){
						listObjective[j].city1 = comparelist[j].city1;
						listObjective[j].city2 = comparelist[j].city2;
						listObjective[j].score = comparelist[j].score;
						*bestscore = currentscore + comparelist[CurrentLength].score;
				}
			}
		}
		if(Tracks.takenTracks[city1][city2] == 0 ){
			*minLength = CurrentLength+1;
		}
	}
	else{	
		for(int i=city2; i>city1-3 && i>0; i--){
			if( Tracks.lengthTracks[i][city2] > 0 && ((Tracks.takenTracks[i][city2] == 0)|| (Tracks.takenTracks[i][city2] == 1 ))){
				comparelist[CurrentLength].city1 = i;
				comparelist[CurrentLength].city2 = city2;
				comparelist[CurrentLength].score = calculescore(Tracks.lengthTracks[i][city2]);
				
				if(Tracks.takenTracks[city1][city2] == 0){
					recursiveStrat_decreasing(city1, i, Tracks, CurrentLength+1, minLength, listObjective, comparelist, bestscore, currentscore + comparelist[CurrentLength].score, dataPlayer);
				}
				else{
					recursiveStrat_decreasing(city1, i, Tracks, CurrentLength, minLength, listObjective, comparelist, bestscore, currentscore + comparelist[CurrentLength].score, dataPlayer);
				}
			}
		}
	}
}	
		
void Strat(int city1, int city2, t_dataTracks Tracks, t_objective BestlistObjective[][35], t_dataPlayer dataPlayer, int number){

	int a = city1;
	int b = city2;
	int temp = city2;
	
	int minLength_increasing = 35;
	int minLength_decreasing = 35;
	int Increasing_score = 0;
	int Decreasing_score = 0;
	int currentLength = 0;
	int currentscore = 0;
	
	t_objective listObjective_increasing[35];
	t_objective listObjective_decreasing[35];
	t_objective comparelistObjective[35];
	
	if(a > b){
		b = city1;
		a = temp;
	}
	
	recursiveStrat_increasing(a, b, Tracks, currentLength, &minLength_increasing , listObjective_increasing, comparelistObjective, &Increasing_score, currentscore, dataPlayer);
	recursiveStrat_decreasing(a, b, Tracks, currentLength, &minLength_decreasing , listObjective_decreasing, comparelistObjective, &Decreasing_score, currentscore, dataPlayer);
	
	if(minLength_increasing <= minLength_decreasing){
			for(int i=0; i<minLength_increasing; i++){
				BestlistObjective[number][i].city1 = listObjective_increasing[i].city1;
				BestlistObjective[number][i].city2 = listObjective_increasing[i].city2;
				BestlistObjective[number][i].score = listObjective_increasing[i].score;
			}
	}
	else{
		if(Increasing_score >= Decreasing_score){
			for(int i=0; i<minLength_increasing; i++){
				BestlistObjective[number][i].city1 = listObjective_increasing[i].city1;
				BestlistObjective[number][i].city2 = listObjective_increasing[i].city2;
				BestlistObjective[number][i].score = listObjective_increasing[i].score;
			}
		}
		else{
			for(int i=0; i<minLength_decreasing; i++){
				BestlistObjective[number][i].city1 = listObjective_decreasing[i].city1;
				BestlistObjective[number][i].city2 = listObjective_decreasing[i].city2;
				BestlistObjective[number][i].score = listObjective_decreasing[i].score;
			}
		}
	}
}			

void NewObjective(t_move* move, t_dataPlayer dataPlayer, t_dataTracks Tracks, int tabObjective[3]){
	
	t_objective temp[3]; 
	t_objective pathObjective[3][35];
	int TotalScore[] = {0, 0, 0};
	int TotalWagon[] = {0, 0, 0};
	float ScorePerWagon[] = {0, 0, 0};
	
	for(int i=0; i<3; i++){
		temp[i].city1 = move->drawObjectives.objectives[i].city1;
		temp[i].city2 = move->drawObjectives.objectives[i].city2;
		temp[i].score = move->drawObjectives.objectives[i].score;
		Strat(temp[i].city1, temp[i].city2, Tracks, pathObjective, dataPlayer, i);
		for(int j=0; temp[j].score != 0; j++){
			TotalScore[i] = TotalScore[i] + temp[j].score;
			TotalWagon[i] = TotalWagon[i] + Tracks.lengthTracks[temp[i].city1][temp[i].city2];
		}
		
		if(TotalWagon[i] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
			tabObjective[i] = 0;	/* If we don't have the amount of wagon, we don't take the objective */
		}
		else{
			tabObjective[i] = 1;	/* If we have the amount of wagon, we take the objective */
		}
	}
	for(int i=0; i<3; i++){
		ScorePerWagon[i] = TotalScore[i]*1.0 / TotalWagon[i];
	}
		
	for(int i=0; i<3; i++){
		if(tabObjective[i] == 1){
			for(int j=i+1; j<3; j++){
				if(tabObjective[j] == 1){
					if(j+1 == 2 && tabObjective[2] == 1){
						if( TotalWagon[i] + TotalWagon[j] + TotalWagon[2] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
							if( ScorePerWagon[0] < ScorePerWagon[1] && ScorePerWagon[0] < ScorePerWagon[2]){
								if( TotalWagon[1] + TotalWagon[2] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
									if( ScorePerWagon[1] > ScorePerWagon[2]){
										tabObjective[0] = 0;
										tabObjective[1] = 1;
										tabObjective[2] = 0;
									}
									else{
										tabObjective[0] = 0;
										tabObjective[1] = 0;
										tabObjective[2] = 1;
									}
								}
								else{
									tabObjective[0] = 0;
									tabObjective[1] = 1;
									tabObjective[2] = 1;
								}
							}
							else if( ScorePerWagon[1] < ScorePerWagon[0] && ScorePerWagon[1] < ScorePerWagon[2]){
								if( TotalWagon[0] + TotalWagon[2] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
									if( ScorePerWagon[0] > ScorePerWagon[2]){
										tabObjective[0] = 1;
										tabObjective[1] = 0;
										tabObjective[2] = 0;
									}
									else{
										tabObjective[0] = 0;
										tabObjective[1] = 0;
										tabObjective[2] = 1;
									}
								}
								else{
									tabObjective[0] = 1;
									tabObjective[1] = 0;
									tabObjective[2] = 1;
								}
							}
							else{
								if( TotalWagon[0] + TotalWagon[1] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
									if( ScorePerWagon[0] > ScorePerWagon[1]){
										tabObjective[0] = 1;
										tabObjective[1] = 0;
										tabObjective[2] = 0;
									}
									else{
										tabObjective[0] = 0;
										tabObjective[1] = 1;
										tabObjective[2] = 0;
									}
								}
								else{
									tabObjective[0] = 1;
									tabObjective[1] = 1;
									tabObjective[2] = 0;
								}
							}
						}
					}
					else if(TotalWagon[i] + TotalWagon[j] > dataPlayer.Player[dataPlayer.num_player].nb_wagon){
						if( ScorePerWagon[i] > ScorePerWagon[j]){
							tabObjective[i] = 1;
							tabObjective[j] = 0;
						}
						else{
							tabObjective[i] = 0;
							tabObjective[j] = 1;
						}
					}
					else{
						tabObjective[i] = 1;
						tabObjective[j] = 1;
					}
				}
			}
		}
	}
}
				
void Fake_IA(t_move* move, t_move* OurLastMove, t_dataPlayer dataPlayer, t_dataMap dataMap, t_dataTracks Tracks, t_objective Bestpath[][35]){

	int CheckObjective = 1;
	int IndexNotCompleted;
	int tabObjective[3];
	int NumberLocomotive = dataPlayer.Player[dataPlayer.num_player].nb_color_cards[9];
	
	for(int i=0; i<dataPlayer.Player[dataPlayer.num_player].nb_objectif; i++){			/* Check if we have completed all our objective or not */
		if(dataPlayer.Player[dataPlayer.num_player].completedobjective[i] == 0){
			CheckObjective = 0;
			IndexNotCompleted = i;														/* Collect the index of the objective that we don't completed */
			break;
		}
	}
		
	if( ((OurLastMove->type == DRAW_CARD) || (OurLastMove->type == DRAW_BLIND_CARD)) && dataPlayer.replay == 1){
	
		/*for(int i=0; Bestpath[IndexNotCompleted][i].score != 0 ; i++){
			if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] > dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] && 
			Tracks.takenTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] == 0){
					
				for(int j=0; j<5; j++){
					if(dataMap.faceUp[j] == Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]){
							
						move->type = DRAW_CARD;
						OurLastMove->type = DRAW_CARD;
						move->drawCard.card = dataMap.faceUp[j];
						printf("We Draw card of color number : %d\n", dataMap.faceUp[j]);
						return;
					}
							
					else if(dataMap.faceUp[j] == Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]){
							
						move->type = DRAW_CARD;
						OurLastMove->type = DRAW_CARD;
						move->drawCard.card = dataMap.faceUp[j];
						printf("We Draw card of color number : %d\n", dataMap.faceUp[j]);
						return;
					}
				}
			}
		}*/

		move->type = DRAW_BLIND_CARD;
		OurLastMove->type = DRAW_BLIND_CARD;
		return;

	}
	else{
		if(CheckObjective == 1 && OurLastMove->type != DRAW_OBJECTIVES){					/* If have completed all our objective, we pick other objective*/
			move->type = DRAW_OBJECTIVES;
			OurLastMove->type = DRAW_OBJECTIVES;
			printf("We draw an objective\n");
			return;
		}
		
		else if(OurLastMove->type == DRAW_OBJECTIVES){										/* If we have DRAW_OBJECTIVE on our last move, we choose the objective to keep */
			move->type = CHOOSE_OBJECTIVES;
			OurLastMove->type = CHOOSE_OBJECTIVES;
			
			NewObjective(move, dataPlayer, Tracks, tabObjective);
			for(int i=0; i<3; i++){
				move->chooseObjectives.chosen[i] = tabObjective[i];
			}
			printf("We choose objective\n");
			return;
		}
		

		for(int i=0; Bestpath[IndexNotCompleted][i].score != 0; i++){
			if(Tracks.takenTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] != 1){
				
				if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] <= dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] ){
						
					/* If we have enough wagon of the first color we use it */
						
					move->type = CLAIM_ROUTE;
					OurLastMove->type = CLAIM_ROUTE;
					move->claimRoute.city1 = Bestpath[IndexNotCompleted][i].city1;
					move->claimRoute.city2 = Bestpath[IndexNotCompleted][i].city2;
					move->claimRoute.color = Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2];
					move->claimRoute.nbLocomotives = 0;
					
					printf("We claim a route\n");
					printf(" city1 = %d, city2 = %d\n", move->claimRoute.city1, move->claimRoute.city2);
					return;
				}
					
				else if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] <= 					dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] ){
						
					/* else If we have enough wagon of the second color we use it */
						
					move->type = CLAIM_ROUTE;
					OurLastMove->type = CLAIM_ROUTE;
					move->claimRoute.city1 = Bestpath[IndexNotCompleted][i].city1;
					move->claimRoute.city2 = Bestpath[IndexNotCompleted][i].city2;
					move->claimRoute.color = Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2];
					move->claimRoute.nbLocomotives = 0;	
						
					printf("We claim a route\n");
					printf(" city1 = %d, city2 = %d\n", move->claimRoute.city1, move->claimRoute.city2);
					return;	
					
					}	
					
				else if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] <= dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] + NumberLocomotive){
					
						/* else If we have enough wagon of the first color + locomotive we use it */
						
					move->type = CLAIM_ROUTE;
					OurLastMove->type = CLAIM_ROUTE;
					move->claimRoute.city1 = Bestpath[IndexNotCompleted][i].city1;
					move->claimRoute.city2 = Bestpath[IndexNotCompleted][i].city2;
					move->claimRoute.color = Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2];
					move->claimRoute.nbLocomotives = Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] - dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]];
						
					printf("We claim a route\n");
					printf(" city1 = %d, city2 = %d\n, nb locomotive = %d", move->claimRoute.city1, move->claimRoute.city2, move->claimRoute.nbLocomotives);
					return;
					}
					
				else if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] <= 					dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] + NumberLocomotive){
					
					/* else If we have enough wagon of the second color + locomotive we use it */
						
					move->type = CLAIM_ROUTE;
					OurLastMove->type = CLAIM_ROUTE;
					move->claimRoute.city1 = Bestpath[IndexNotCompleted][i].city1;
					move->claimRoute.city2 = Bestpath[IndexNotCompleted][i].city2;
					move->claimRoute.color = Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2];
					move->claimRoute.nbLocomotives = Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] - dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]];
						
					printf("We claim a route\n");
					printf(" city1 = %d, city2 = %d\n, nb locomotive = %d", move->claimRoute.city1, move->claimRoute.city2, move->claimRoute.nbLocomotives);
					return;
				}
			}
		}
		
		for(int i=0; Bestpath[IndexNotCompleted][i].score != 0 ; i++){
			if(Tracks.lengthTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] > dataPlayer.Player[dataPlayer.num_player].nb_color_cards[Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]] && 
			Tracks.takenTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2] == 0){
					
				for(int j=0; j<5; j++){
					if(dataMap.faceUp[j] == Tracks.colorTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]){
							
						move->type = DRAW_CARD;
						OurLastMove->type = DRAW_CARD;
						move->drawCard.card = dataMap.faceUp[j];
						printf("We Draw card of color number : %d\n", dataMap.faceUp[j]);
						return;
					}
							
					else if(dataMap.faceUp[j] == Tracks.doubleTracks[Bestpath[IndexNotCompleted][i].city1][Bestpath[IndexNotCompleted][i].city2]){
							
						move->type = DRAW_CARD;
						OurLastMove->type = DRAW_CARD;
						move->drawCard.card = dataMap.faceUp[j];
						printf("We Draw card of color number : %d\n", dataMap.faceUp[j]);
						return;
					}
				}
			}
		}
		move->type = DRAW_BLIND_CARD;
		OurLastMove->type = DRAW_BLIND_CARD;
		printf("We Draw blind card\n");
	}
}
		
		











			
			
			
			
			
			
			
			
			
